#include <acado_toolkit.hpp>

int main()
{

    USING_NAMESPACE_ACADO

    double kg = 0.007;
    // INTRODUCE THE VARIABLES (acadoVariables.x):
    // -------------------------
    DifferentialState s;
    DifferentialState v;

    Control a;

    double dt = 0.001; // sampling time for discrete-time system

    // Model equations:
    DifferentialEquation f;

    f << dot(s) == v;
    f << dot(v) == a;
    // f << dot(yaw) == w;

    // Reference functions and weighting matrices:
    Function rf, rfN;
    rf << s << v << a;
    rfN << s << v ;

    BMatrix W = eye<bool>(rf.getDim());
    BMatrix WN = eye<bool>(rfN.getDim());
    //
    // Optimal Control Problem
    //
    OCP ocp(0.0, 1.0, 40);

    ocp.subjectTo(f);

    ocp.subjectTo(-6.0/kg <= a <= 6.0/kg);

    ocp.minimizeLSQ(W, rf);
    ocp.minimizeLSQEndTerm(WN, rfN);

    // Export the code:
    OCPexport mpc(ocp);

    mpc.set(HESSIAN_APPROXIMATION, GAUSS_NEWTON);
    // mpc.set(DISCRETIZATION_TYPE, SINGLE_SHOOTING);
    mpc.set(DISCRETIZATION_TYPE, MULTIPLE_SHOOTING);
    mpc.set(INTEGRATOR_TYPE, INT_RK45);
    // mpc.set(INTEGRATOR_TYPE, INT_IRK_RIIA3);
    mpc.set(NUM_INTEGRATOR_STEPS, 9*40);
    mpc.set(SPARSE_QP_SOLUTION, FULL_CONDENSING);
    //	mpc.set(SPARSE_QP_SOLUTION, CONDENSING);
    mpc.set(QP_SOLVER, QP_QPOASES);
    //	mpc.set(QP_SOLVER, QP_FORCES);
    mpc.set(MAX_NUM_QP_ITERATIONS, 999);
    mpc.set(HOTSTART_QP, YES);
    //	mpc.set(SPARSE_QP_SOLUTION, SPARSE_SOLVER);
    mpc.set(LEVENBERG_MARQUARDT, 1.0E2);
    mpc.set(GENERATE_TEST_FILE, YES);
    mpc.set(GENERATE_MAKE_FILE, YES);
    mpc.set(GENERATE_MATLAB_INTERFACE, YES);
    //	mpc.set(USE_SINGLE_PRECISION, YES);
    mpc.set(CG_USE_VARIABLE_WEIGHTING_MATRIX, YES);
    mpc.set(CG_HARDCODE_CONSTRAINT_VALUES, NO);

    if (mpc.exportCode("getting_started_export") != SUCCESSFUL_RETURN)
        exit(EXIT_FAILURE);

    mpc.printDimensionsQP();

    return EXIT_SUCCESS;
}
